from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI
import asyncio
import logging
import json
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import os
from functions import store_user_info, create_single_use_scheduling_link


OPENAI_API_KEY = 'sk-proj-Im48k4cpTvVVD561KeO5T3BlbkFJaevYGk7J3IDFmZGK6d5c'

client = OpenAI(api_key=OPENAI_API_KEY)


# Initialize FastAPI app
app = FastAPI()

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")


session_threads = {}
logger = logging.getLogger("uvicorn")

# Message model for incoming requests
class Message(BaseModel):
    session_id: str
    message: str


# Sample handle_user_messages function you provided
async def handle_user_messages(session_id, text):
    if session_id not in session_threads:
        thread = client.beta.threads.create()
        session_threads[session_id] = thread.id

    thread_id = session_threads[session_id]
    content_list = []
    
    content_list.append({"type": "text", "text": text})

    logger.info(content_list)
    
    try:
        # Send collected messages to the LLM
        client.beta.threads.messages.create(thread_id=thread_id, role="user", content=content_list)
        run = client.beta.threads.runs.create(thread_id=thread_id, assistant_id="asst_WTmKMGP77EFAllbpJmENYjZB")
        
        while True:
            try:
                run_status = client.beta.threads.runs.retrieve(thread_id=thread_id,
                                                            run_id=run.id)
                logger.info(f"Run status: {run_status.status}")

                if run_status.status == 'completed':
                    break
                if run_status.status == 'failed':
                    logger.error(f"Run failed with error: {run_status.status}")
                    break

                elif run_status.status == 'requires_action':
                    tool_calls_res = []
                    for tool_call in run_status.required_action.submit_tool_outputs.tool_calls:
                        try:
                            logger.info(tool_call.function)
                            if tool_call.function.name == "store_user_info":
                                arguments = json.loads(tool_call.function.arguments)
                                output = store_user_info(arguments['link'], arguments['username'], arguments['request'])
                                tool_calls_res.append({"tool_call_id": tool_call.id, "output": output})

                            elif tool_call.function.name == "create_single_use_scheduling_link":
                                arguments = json.loads(tool_call.function.arguments)
                                output = create_single_use_scheduling_link()
                                tool_calls_res.append({"tool_call_id": tool_call.id, "output": str(output)})

                            else:
                                logger.warning(f"Unknown function name: {tool_call.function.name}")

                        except Exception as e:
                            logger.error(f"Error processing tool call {tool_call.id}: {e}")
                            break
                        except Exception as e:
                            logger.error(f"Error processing tool call {tool_call.id}: {e}")
                            break
                    logger.info('---'*50)
                    logger.info(tool_calls_res)
                    client.beta.threads.runs.submit_tool_outputs(thread_id=thread_id,
                                                                run_id=run.id,
                                                                tool_outputs=tool_calls_res)
            except Exception as e:
                logger.error(f"Error retrieving run status: {e}")
                break

            await asyncio.sleep(1)  # Wait for a second before checking again

        messages = client.beta.threads.messages.list(thread_id=thread_id)
        response = messages.data[0].content[0].text.value
        
        
        return response

    except Exception as e:
        logger.error(f"Error processing messages for user {session_id}: {e}")

# Chat endpoint
@app.post("/chat")
async def chat(message: Message):
    try:
        logger.info(message)
        response = await handle_user_messages(message.session_id, message.message)
        return {"response": response}
    except Exception as e:
        logger.error(f"Error processing chat message: {e}")
        raise HTTPException(status_code=500, detail="Error processing message")



@app.get("/", response_class=HTMLResponse)
async def serve_html():
    with open("static/index.html") as file:
        html_content = file.read()
    return HTMLResponse(content=html_content, status_code=200)
