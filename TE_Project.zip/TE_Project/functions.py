import requests
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials



scope = [
    "https://spreadsheets.google.com/feeds",
    'https://www.googleapis.com/auth/spreadsheets',
    "https://www.googleapis.com/auth/drive.file",
    "https://www.googleapis.com/auth/drive"
]

creds = ServiceAccountCredentials.from_json_keyfile_name(
    'credentials.json', scope)
gc = gspread.authorize(creds)
sh = gc.open('consultations')
worksheet = sh.worksheet('Sheet1')

ACCESS_TOKEN = "eyJraWQiOiIxY2UxZTEzNjE3ZGNmNzY2YjNjZWJjY2Y4ZGM1YmFmYThhNjVlNjg0MDIzZjdjMzJiZTgzNDliMjM4MDEzNWI0IiwidHlwIjoiUEFUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiJodHRwczovL2F1dGguY2FsZW5kbHkuY29tIiwiaWF0IjoxNzI3ODEzNTIxLCJqdGkiOiI4NmU1ZDdiOS1mNzM0LTQ1ZjUtYmQ4My1iOTg2ZTRiMjk3MTEiLCJ1c2VyX3V1aWQiOiJjNjgzYWI0OS04Njg4LTRmYTUtYWQ3My02M2FlM2ZhMDc3NDUifQ.F7sEHLowWLZb92BInMO1EIRhdqO07hUYF3FP4lY3H4aTAiBS5gF8t1HrxjrEB6IRXLRRCb3VrK0qFwey1-kkBw"
USER_URI = "https://api.calendly.com/users/c683ab49-8688-4fa5-ad73-63ae3fa07745"
EVENT_UUID = "8b156538-9f83-4daf-a6c8-2ae568fd6ede"
HEADERS = {
    "Authorization": f"Bearer {ACCESS_TOKEN}",
    "Content-Type": "application/json"
}


def create_single_use_scheduling_link():
    """
    Generates a single-use scheduling link for a specific Calendly event.
    
    Args:
        invitee_email (str): The email of the invitee who will receive the link.
        
    Returns:
        str: The single-use scheduling link or an error message.
    """
    scheduling_link_url = "https://api.calendly.com/scheduling_links"
    
    # Prepare the payload for the request
    payload = {
        "max_event_count": 1, 
        "owner": f"https://api.calendly.com/event_types/{EVENT_UUID}",  
        "owner_type": "EventType"
    }
    
    response = requests.post(scheduling_link_url, headers=HEADERS, json=payload)
    
    if response.status_code == 201:
        scheduling_link = response.json().get('resource', {}).get('booking_url', '')
        return scheduling_link
    else:
        return f"Error: {response.status_code}, {response.text}"

print(create_single_use_scheduling_link())

def store_user_info(link, username, request):
    try:
        # Prepare the values to be added in the new row
        values = [username, link, request, datetime.now().strftime('%d.%m.%Y %H:%M:%S')]
        
        # Append the new row at the end of the sheet
        worksheet.append_row(values, value_input_option='USER_ENTERED')

        return f"User {username} added successfully with values: {values}"
        print(f"User {username} added successfully with values: {values}")

    except Exception as e:
        return f"Failed to store user info for {username}: {str(e)}"
        print(f"Failed to store user info for {username}: {str(e)}")
